# How to Install MongoDB on Kubernetes?

[YouTube Tutorial](https://youtu.be/Voj9kIBhzR4)
