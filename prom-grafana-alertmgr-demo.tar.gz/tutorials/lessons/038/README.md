# Terraform EKS Cluster Creation
**YouTube** [Playlist](https://youtube.com/playlist?list=PLiMWaCMwGJXkeBzos8QuUxiYT6j8JYGE5)
