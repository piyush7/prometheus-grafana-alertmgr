# How to Create EKS Cluster Using Terraform

 You can find tutorial [here](https://antonputra.com/Terraform/how-to-create-eks-cluster-using-terraform/).
