# How to Install Prometheus and Grafana on Ubuntu?

You can find tutorial [here](https://antonputra.com/monitoring/Install-prometheus-and-grafana-on-ubuntu/).
