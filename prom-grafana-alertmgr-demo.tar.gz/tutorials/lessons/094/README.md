# Kubernetes Quality of Service (QoS) Classes for Pods (Guaranteed, Burstable, BestEffort)

[YouTube Tutorial](https://youtu.be/ka-HItczp2I)

## Links

- [stress-ng](https://unix.stackexchange.com/questions/99334/how-to-fill-90-of-the-free-memory)
