# Kubernetes Taints and Tolerations

[YouTube Tutorial](https://youtu.be/6EMtEJC00FY)

```bash
kubectl get nodes
kubectl taint nodes node1 role=spot:NoSchedule
kubectl get pods
```
