# How to Generate Self-Signed Certificate?

[YouTube Tutorial](https://antonputra.com/how-to-generate-self-signed-certificate/)
