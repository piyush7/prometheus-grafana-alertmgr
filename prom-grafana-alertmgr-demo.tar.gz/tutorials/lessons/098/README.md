# Kubernetes Pod Disruption Budget

[YouTube Tutorial](https://youtu.be/e2HjRrmXMDw)
