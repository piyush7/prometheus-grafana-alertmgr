# IAM Roles for Service Accounts & Pods: (IRSA EKS | IAM OIDC Provider | AWS EKS | Kubernetes)

[Step by Step Tutorial](https://youtu.be/bu0M2y2g1m8)
