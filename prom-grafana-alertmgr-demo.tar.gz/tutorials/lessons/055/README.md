# How to Run Nginx Docker Container?

[Step by Step Tutorial](https://antonputra.com/how-to-run-nginx-docker-container-with-ssl-certificate/)
