# Kubernetes Affinity and Anti Affinity vs NodeSelector (Examples)

[YouTube Tutorial](https://youtu.be/DKLMzDD3xqA)
