# Kubernetes NodePort vs LoadBalancer vs Ingress?

[YouTube Tutorial](https://youtu.be/UzCgEVqIhg0)
