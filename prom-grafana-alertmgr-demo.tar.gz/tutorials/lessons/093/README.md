# Kubernetes Basics: Pods, Nodes, Containers, Deployments and Clusters

[YouTube Tutorial](https://youtu.be/B_X4l4HSgtc)
