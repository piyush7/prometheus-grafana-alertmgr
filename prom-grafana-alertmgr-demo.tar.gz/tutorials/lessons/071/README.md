# Kubernetes Horizontal Pod Autoscaler

[YouTube Tutorial](https://youtu.be/pI_pMsuazqw)
