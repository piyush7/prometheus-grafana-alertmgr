# How to Add IAM User and IAM Role to AWS EKS Cluster?

 You can find tutorial [here](https://antonputra.com/Kubernetes/add-iam-user-and-iam-role-to-eks/).
